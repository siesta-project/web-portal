#!/bin/bash
#SBATCH -J tutorialXX
#SBATCH -n 4
#SBATCH -t 0:30:00
#SBATCH -o %x-%j.out
#SBATCH -e %x-%j.err
#SBATCH -D .

# DO NOT CHANGE THIS LINE
source /gpfs/projects/nct00/nct00003/siestarc.sh

# EDIT THE CORRECT INPUT AND OUTPUT FILES.
srun -n 4 siesta < input.fdf > output.out

